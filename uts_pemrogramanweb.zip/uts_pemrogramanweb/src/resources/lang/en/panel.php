<?php

return [
    'site_title' => 'Template',

];
